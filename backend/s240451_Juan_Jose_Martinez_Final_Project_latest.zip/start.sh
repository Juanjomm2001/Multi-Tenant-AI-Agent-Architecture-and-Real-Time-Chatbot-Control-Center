#!/bin/bash


echo "Initializing databases..."
python init_db.py

echo "Starting FastAPI backend..."
uvicorn main:app --host 0.0.0.0 --port 8000 &

sleep 3

echo "Starting Streamlit frontend..."
streamlit run app.py --server.port 8501 --server.address 0.0.0.0
